package com.example.vislice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class konec extends AppCompatActivity {

    private Button button1;
    private Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_konec);
        button1=findViewById(R.id.Ponovno);
        button2=findViewById(R.id.koncaj);
        button1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                ponovno();
            }
        });
        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                koncaj();
            }
        });
    }

    public void ponovno(){
        game.crtice="";
        game.narobe=0;
        Intent intent = new Intent(this, game.class);startActivity(intent);
    }
    public void koncaj(){
        finish();
        System.exit(0);
    }
}
